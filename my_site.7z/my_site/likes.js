let likes = 0;
function like()
{
likes++;
document.getElementById("likes").innerHTML = likes;
console.log(likes);
}