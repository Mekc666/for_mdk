function mama(){

    let a = document.getElementById('log').value;
    let b = document.getElementById('pass').value;
    document.getElementById("vash_log").innerHTML = "Ваш логин: " + a;
    document.getElementById("parol").innerHTML = "Ваш пароль: " + b;
}