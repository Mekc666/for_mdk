function turbo(n, k) //Функция сочетания
{
let result;
if(n == k) result = 0; //Если ингрендиентов 2, то салатов выйдет в итоге 1
else
{
let p = 1;
for(let i = 1; i != n-k; i++)
{
p = p*(k+i)/i; //Формула сочетания
}
result = Math.trunc(p); //Результат
}
return result; //Возвращается
}

function moveCrus()
{
let n = Number(document.getElementById("num").value)+1; //Ингрендиенты
if(n < 33) //Если меньше 32
{
let s = 1; //Кол-во салатов
for (let i = 2; i != n-1; i++)
{
s = s + turbo(n, i); //Кол-во салатов увеличивается
}
document.getElementById("s").innerHTML = "Количество салатов: " + s; //Вывод кол-ва салатов
}
else document.getElementById("s").innerHTML = "Слишком много ингрендиентов"; //Иначе ошибка
}

